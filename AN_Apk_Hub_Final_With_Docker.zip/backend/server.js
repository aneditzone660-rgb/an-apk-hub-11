// server.js - AN Apk Hub Final
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const helmet = require('helmet');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const DB_FILE = path.join(__dirname, 'apks.json');
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify([]));

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'ahmednahid';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Nahid@73';
const DEFAULT_TOKEN = process.env.ADMIN_TOKEN || 'Nahid@73-token';

const app = express();
app.use(helmet());
app.use(express.json());
app.use(cors());

app.use(express.static(path.join(__dirname, '..', 'frontend', 'build')));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const safe = Date.now() + '-' + file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, safe);
  }
});
const upload = multer({ storage, limits: { fileSize: 300 * 1024 * 1024 } });

function readDB(){ try { return JSON.parse(fs.readFileSync(DB_FILE)); } catch(e){ return []; } }
function writeDB(data){ fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2)); }

// login -> returns token if username/password correct
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    // issue a random token
    const token = DEFAULT_TOKEN; // simple fixed token for demo
    return res.json({ ok: true, token });
  }
  return res.status(401).json({ error: 'Invalid credentials' });
});

// upload (requires token in header x-admin-token)
app.post('/api/upload', upload.single('apk'), (req, res) => {
  const token = req.headers['x-admin-token'] || req.body.admin_token;
  if (!token || (token !== DEFAULT_TOKEN && token !== process.env.ADMIN_TOKEN)) {
    if (req.file && req.file.path) fs.unlinkSync(req.file.path);
    return res.status(401).json({ error: 'Unauthorized' });
  }
  if (!req.file) return res.status(400).json({ error: 'No file' });
  const { version, description } = req.body;
  const stats = fs.statSync(req.file.path);
  const item = {
    id: uuidv4(),
    filename: req.file.filename,
    original_name: req.file.originalname,
    version: version || '',
    size: stats.size,
    uploaded_at: new Date().toISOString(),
    description: description || '',
    downloads: 0
  };
  const db = readDB();
  db.unshift(item);
  writeDB(db);
  res.json({ ok: true, item });
});

// list
app.get('/api/apks', (req, res) => {
  const db = readDB();
  res.json(db);
});

// download (increments counter)
app.get('/download/:filename', (req, res) => {
  const fname = path.basename(req.params.filename);
  const db = readDB();
  const item = db.find(i=>i.filename===fname);
  const filePath = path.join(UPLOAD_DIR, fname);
  if (!item || !fs.existsSync(filePath)) return res.status(404).send('Not found');
  item.downloads = (item.downloads||0) + 1;
  writeDB(db);
  res.download(filePath, item.original_name, err=>{ if(err) console.error(err); });
});

// fallback SPA
app.get('*', (req, res) => {
  const index = path.join(__dirname, '..', 'frontend', 'build', 'index.html');
  if (fs.existsSync(index)) res.sendFile(index);
  else res.status(404).send('Not found');
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log('Server started on', PORT));
