import React, { useEffect, useState } from 'react';
import './App.css';

export default function App(){
  const [apks, setApks] = useState([]);
  const [q, setQ] = useState('');
  const [showLogin, setShowLogin] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState('');
  const [file, setFile] = useState(null);
  const [version, setVersion] = useState('');
  const [desc, setDesc] = useState('');

  useEffect(()=>{ fetch('/api/apks').then(r=>r.json()).then(setApks).catch(()=>{}); }, []);

  const doLogin = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});
    if(res.ok){ const data = await res.json(); setToken(data.token); setShowLogin(true); alert('Login success'); }
    else { alert('Login failed'); }
  };

  const doUpload = async (e) => {
    e.preventDefault();
    if(!file) return alert('Choose .apk file');
    const fd = new FormData();
    fd.append('apk', file);
    fd.append('version', version);
    fd.append('description', desc);
    const res = await fetch('/api/upload', { method: 'POST', body: fd, headers: { 'x-admin-token': token } });
    if(res.ok){ alert('Uploaded'); setFile(null); setVersion(''); setDesc(''); setToken(''); setShowLogin(false); setApks(await (await fetch('/api/apks')).json()); }
    else { const data = await res.json().catch(()=>({})); alert('Upload failed: '+ (data.error||res.status)); }
  };

  const filtered = apks.filter(a=> a.original_name.toLowerCase().includes(q.toLowerCase()) || (a.version||'').toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="app">
      <header className="header">
        <div className="brand"><img src="/favicon.png" alt="logo" className="logo"/> <div><div className="title">AN Apk Hub</div><div className="subtitle">Your trusted APK sharing platform</div></div></div>
        <div className="actions"><button onClick={()=>setShowLogin(s=>!s)} className="admin-btn">Admin Login</button></div>
      </header>
      <main className="main">
        {showLogin && <section className="upload">
          <h3>Admin Login / Upload</h3>
          {!token ? (
            <form onSubmit={doLogin}>
              <input type="text" placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} />
              <input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
              <button type="submit">Login</button>
            </form>
          ) : (
            <form onSubmit={doUpload}>
              <input type="text" placeholder="Version (e.g. 1.0.2)" value={version} onChange={e=>setVersion(e.target.value)} />
              <input type="file" accept=".apk" onChange={e=>setFile(e.target.files[0])} />
              <textarea placeholder="Description" value={desc} onChange={e=>setDesc(e.target.value)}></textarea>
              <button type="submit">Upload APK</button>
            </form>
          )}
        </section>}

        <section className="list">
          <div className="search"><input placeholder="Search by name or version" value={q} onChange={e=>setQ(e.target.value)} /></div>
          <ul>
            {filtered.map(a=> (
              <li key={a.id} className="card">
                <div className="left">
                  <div className="name">{a.original_name}</div>
                  <div className="meta">Version: {a.version || '—'} • {Math.round(a.size/1024)} KB • {new Date(a.uploaded_at).toLocaleString()}</div>
                  <div className="desc">{a.description}</div>
                </div>
                <div className="right">
                  <a className="download" href={a.download_url}>Download</a>
                  <div className="count">Downloads: {a.downloads||0}</div>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </main>
      <footer className="footer">© 2025 AN Apk Hub. All rights reserved.</footer>
    </div>
  );
}
